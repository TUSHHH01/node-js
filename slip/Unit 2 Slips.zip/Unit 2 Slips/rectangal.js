function area_rec(l,b){
    var result = l  * b ;
    console.log("Area of Rectangle : " + result) ;
}
module.exports = area_rec ;