console.log(new Date());
console.log(new Date(dob));