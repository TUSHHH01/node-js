var http = require('http');
// var url = ('url');
http.createServer(function(req, res) {
    res.writeHead(200, {'Content-Type': 'text/html'});
    var input = 'tushar is good boy';

    function vowelCount(input) {
        var count = 0; // Initialize count to 0
        var vowels = 'aeiouAEIOU';
        for (let char of input) {
            if (vowels.includes(char)) {
                count++;
            }
        }
        return count;
    }
    
    res.end('Number of vowels: ' + vowelCount(input));
}).listen(8080);

