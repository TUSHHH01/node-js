function displayAffectedRows(result){
//     console.log("Affected Rows: " + result.affectedRows);
// }