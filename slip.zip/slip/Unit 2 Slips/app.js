/* 
// card number 
const maskCardNumber = require("./card.js");

const cardnumber = process.argv[2];
 
console.log(maskCardNumber(cardnumber));
*

/*
// leap year

const cheakleapYear = require('./leapyear.js');

var year = process.argv[2];

cheakleapYear(year);*/

/*
// vowel
const countVowel = require('./vowel.js');

const input = process.argv[2];

countVowel(input);
*/

/*
// palindrome 
const isPalindromeString = require('./palindrome.js');
const isPalindromeNumber = require('./palindromeNumber.js');

var inputString = process.argv[2];
var inputNumber = process.argv[3];

isPalindromeString(inputString);
isPalindromeNumber(inputNumber);
*/

/*
// factorial 
const factorial = require('./factorial.js');

const input = 4 ;

const result = factorial(input);

console.log("The factorial of given Number is : " + result);
*/

/*
// area of circle 

const circle = require('./circle.js');

const radius = process.argv[2];

console.log("Circumfurance of circle : " + circle.circumfurance(radius));
console.log("Circumfurance of circle : " + circle.area(radius));

*/


// area of rectangle 

/*
const rectangle = require('./rectangal.js');

var l = process.argv[2]; 
var b = process.argv[3]; 

console.log("Area of Rectangle : " + rectangle(l,b));
*/