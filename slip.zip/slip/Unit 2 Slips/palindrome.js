// palindromeString.js
module.exports = function isPalindromeString(inputString) {
    const alphanumericStr = inputString.toLowerCase();
    const reversedStr = alphanumericStr.split('').reverse().join('');
    if(alphanumericStr === reversedStr){
        console.log(inputString + " It is palindrome ");
    }else{
        console.log(inputString + " It is not palinderom");
    }
    
};