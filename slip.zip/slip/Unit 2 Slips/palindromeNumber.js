// palindromeNumber.js
module.exports = function isPalindromeNumber(inputNumber) {
    const numStr = inputNumber.toString();
    const reversedStr = numStr.split('').reverse().join('');
   if(numStr === reversedStr){
    console.log(inputNumber + " It is palindrome ");
   }
   else{
    console.log( inputNumber + " it is not palindrome");
   }
};
