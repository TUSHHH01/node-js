function factorial(input){
    var i ;
    var b = 1;
    for(i = input ; i >= 1 ; i--){
        // b *= i ; 
        b = b * i ; 
    }
    return b ;
}
module.exports = factorial ;