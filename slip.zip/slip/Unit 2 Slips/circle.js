function circumfurance(radius){
    var p = 3.14 ;
    var c = 2 * p * radius;
    return c ;
}
function area(radius){
    var p = 3.14 ;
    var c = p * (radius*radius);
    return c ;
}
module.exports = {circumfurance : circumfurance ,
                     area : area                         
                    };
// module.exports = area : area ;
